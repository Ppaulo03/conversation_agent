# Invariantes normativas — conversation_agent v4

Este documento é a referência curta para invariantes que devem permanecer verdadeiras independentemente de adapter, provider, tenant ou domínio.

Toda alteração arquitetural que possa violar uma invariante deve atualizar também o teste nomeado correspondente.

As seguintes regras são normativas para a v1:

```text
INV-001  core/engine nunca importam adapters ou SDKs externos.
INV-002  o LLM nunca fornece tenant_id, contact_id, conversation_id ou secrets.
INV-003  toda operação externa passa por Capability -> Binding -> PolicyGate -> ToolRunner.
INV-004  toda ação protegida possui action_id persistente e confirmation action-scoped.
INV-005  confirmação aceita e ToolInvocation(PREPARED) são persistidas atomicamente.
INV-006  ToolInvocation UNKNOWN nunca sofre retry cego.
INV-007  Outbound só é entregue a partir da Durable Outbox.
INV-008  business state pertence aos sistemas externos; o runtime guarda apenas estado conversacional.
INV-009  toda mutação de conversa valida conversation_epoch/fencing token atual.
INV-010  alteração de argumento protegido invalida confirmação anterior.
INV-011  perda do conversation lease impede mutação de conversa, mas não impede o executor ainda válido de registrar o fato externo no ledger usando execution_epoch.
INV-012  cancelamento/restart só é aplicado em fronteiras seguras de step.
INV-013  mensagens/resultados de tools são dados não confiáveis, nunca instruções privilegiadas.
INV-014  um turno reexecutado reutiliza seu journal persistido antes de chamar novamente LLM ou tool.
INV-015  uma ToolInvocation em FAILED terminal nunca volta a EXECUTING; nova tentativa semântica recebe nova identidade.
INV-016  transições do ledger após I/O externo são cercadas por execution_epoch; aplicação do resultado à conversa é cercada por conversation_epoch.
INV-017  replay do journal é fail-closed: (turn_id, step_index, step_type) identifica o step e request_hash divergente aborta o turno com alerta.
INV-018  cada turno possui turn_reference_time imutável persistido em INBOUND_AGGREGATED; replay nunca recalcula "agora".
INV-019  ownership HUMAN nunca produz resposta automática do bot.
INV-020  evento inbound duplicado nunca cria turno duplicado.
INV-021  retry automático de write/irreversible só é permitido com idempotência explícita e reutilização da mesma idempotency key.
INV-022  prompt de confirmação só é elegível após ACCEPTED pelo canal; QUEUED/SENDING/UNKNOWN não autorizam ação protegida.
INV-023  uma ToolInvocation PREPARED é imutável quanto à operação externa que representa: retry e reconciliation executam a intent congelada no PREPARE e nunca re-resolvem binding/tool com outra versão; se a operação resolvida mudou, falham fechado e escalam.
INV-024  um lease de conversa expirado não autoriza escrita, mesmo antes de qualquer takeover; o heartbeat nunca ressuscita um lease expirado.
INV-025  aguardar o resultado de uma tool (EXECUTING/UNKNOWN/RECONCILING) não é falha do turno e nunca consome tentativas nem dead-letteriza o inbound.
INV-026  provider_accepted_at é o horário de aceite no domínio do canal ou NULL; nunca o relógio local/do banco. Sem timestamp comparável nem reply-to, a resposta é ambígua e o runtime pergunta de novo.
INV-027  uma operação PREPARED não muda de destino: a conexão resolvida (fingerprint sem segredos) e, em status_lookup, o próprio lookup (args + destino) são congelados no PREPARE; mudança de destino/lookup falha fechado (nada é enviado ou decidido).
INV-028  uma versão publicada de agente é imutável (mesmo conteúdo = no-op, outro conteúdo na mesma versão = erro; versões só avançam; mudança incompatível exige bump MAJOR, avaliada sobre o risco/proteção EFETIVOS). Uma conversa fica fixada em (agent_id, versão) enquanto há algo em andamento (outro agente com trabalho aberto falha fechado) e uma invocação é reconciliada com a versão que a preparou; versão ausente falha fechado (nunca outra versão).
INV-029  um agente só roda depois de compilado (o runtime só aceita CompiledAgent, que só o compiler produz): referências, risco, mapeamentos, schemas, error_map e versões inválidos são rejeitados antes do runtime, e o conteúdo carregado deve bater com o digest publicado.
INV-030  o grafo de runtime tem exatamente um CompiledAgent como raiz de definição: engine, pipeline, estágio de confirmação e reconciliation derivam do mesmo agente compilado (versão + digest conferidos); uma protected action nunca existe sem a pergunta de confirmação do runtime (`confirmation_prompt_enabled=false` é rejeitado quando há capability protegida; os templates de confirmação precisam conter `{summary}`).
INV-031  o registry de agentes é tenant-scoped: `(tenant_id, agent_id, version)` é a identidade; um tenant nunca lê nem sombreia agentes de outro.
```

O primeiro agente real deve ser implementado **sem Pack obrigatório**. O primeiro Pack só é extraído depois que existir comportamento reutilizável comprovado.

---

## Mapa INV → teste obrigatório

| Invariante | Teste mínimo |
|---|---|
| INV-001 | `test_architecture_core_engine_do_not_import_adapters` |
| INV-002 | `test_llm_cannot_set_trusted_context_ids_or_secrets` |
| INV-003 | `test_external_operation_always_crosses_policy_gate_and_tool_runner` |
| INV-004 | `test_protected_action_has_persistent_action_id_and_scoped_confirmation` |
| INV-005 | `C02_inside_confirm_prepare_tx`, `C03_after_confirm_prepare_commit` |
| INV-006 | `test_unknown_never_blind_retries` |
| INV-007 | `test_outbound_delivery_only_from_outbox` |
| INV-008 | `test_runtime_does_not_own_business_state` |
| INV-009 | `C09_worker_zombie` |
| INV-010 | `test_changed_protected_args_invalidate_confirmation` |
| INV-011 | `test_lost_conversation_lease_can_finalize_ledger_only`, `C14_lease_lost_after_external_success` |
| INV-012 | `C12_cancel_during_external_call` |
| INV-013 | `test_tool_and_user_content_never_raise_instruction_authority` |
| INV-014 | `C10_after_llm_response`, `C16_after_apply_before_compose` |
| INV-015 | `test_terminal_failed_invocation_requires_new_semantic_attempt` |
| INV-016 | `test_execution_epoch_and_conversation_epoch_have_disjoint_write_boundaries`, `C07_after_ledger_finalize`, `C14_lease_lost_after_external_success` |
| INV-017 | `test_journal_request_hash_divergence_fails_closed`, `C15_journal_hash_divergence` |
| INV-018 | `test_replay_reuses_turn_reference_time` |
| INV-019 | `test_human_owner_never_emits_automated_outbound` |
| INV-020 | `test_duplicate_event_never_creates_duplicate_turn` |
| INV-021 | `test_write_retry_requires_supported_idempotency_and_same_key` |
| INV-022 | `C13_confirm_while_prompt_ambiguous` |
| INV-023 | `test_prepared_invocation_executes_the_frozen_intent_never_a_re_resolved_one`, `test_a_deploy_between_prepare_and_execute_fails_closed_without_sending` |
| INV-024 | `test_an_expired_lease_cannot_open_a_unit_of_work_even_before_any_takeover`, `test_a_heartbeat_cannot_resurrect_an_expired_lease` |
| INV-025 | `test_pending_tool_result_never_exhausts_turn_attempts` |
| INV-026 | `test_a_channel_that_gives_no_timestamp_leaves_accepted_at_null_not_local_time`, `test_a_legitimate_reply_is_eligible_when_the_channel_clock_runs_behind` |
| INV-027 | `test_a_prepared_write_is_never_sent_to_a_destination_it_was_not_prepared_for`, `test_a_changed_lookup_binding_refuses_to_decide_absence`, `test_the_execution_path_refuses_a_stale_destination_without_sending` |
| INV-028 | `test_a_published_version_is_immutable`, `test_published_rows_are_immutable_in_the_database_itself`, `test_a_conversation_stays_on_its_version_while_something_is_in_progress`, `test_an_unknown_write_is_reconciled_with_the_version_that_prepared_it`, `test_reconciliation_never_substitutes_another_version`, `test_a_minor_version_cannot_lower_the_effective_risk`, `test_a_minor_version_cannot_remove_effective_protection`, `test_a_conversation_is_pinned_to_the_agent_not_just_the_version` |
| INV-029 | `tests/compiler/test_compiler.py` (refs, schemas, risco, bindings, versões), `test_a_stored_agent_that_no_longer_matches_its_digest_is_refused`, `test_only_the_compiler_can_produce_a_compiled_agent`, `test_a_mapping_cannot_feed_a_value_of_the_wrong_type` |
| INV-030 | `test_the_engine_refuses_a_pipeline_built_from_another_compiled_agent`, `test_a_protected_agent_cannot_turn_the_confirmation_question_off`, `test_confirmation_texts_must_be_formattable_and_say_what_is_confirmed` |
| INV-031 | `test_the_registry_is_tenant_scoped` |

Os casos `C01`–`C16` (ponto de falha, resultado esperado e fase em que passam a ser exigidos) estão definidos em [`ROADMAP.md`](./ROADMAP.md#chaos-gates).

## Regra de alteração

Uma PR que altera persistência, fencing, idempotência, confirmação, retry ou delivery protocol deve:

1. apontar as invariantes afetadas;
2. atualizar o teste/chaos case correspondente;
3. atualizar `RUNTIME_PROTOCOL.md`;
4. atualizar `ROADMAP.md` se o DoD de alguma fase mudar.
